package com.csslect.app.raspcommand;

import org.springframework.ui.Model;

public interface RaspCommand {
	public void execute(Model model);
}
