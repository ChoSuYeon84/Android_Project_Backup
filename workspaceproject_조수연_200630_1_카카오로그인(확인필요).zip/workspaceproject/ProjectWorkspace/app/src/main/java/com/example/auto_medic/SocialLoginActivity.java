package com.example.auto_medic;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.kakao.auth.AuthType;
import com.kakao.auth.Session;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.LogoutResponseCallback;

public class SocialLoginActivity extends AppCompatActivity {
    private static final String TAG = "mainSocialLoginActivity";

    ImageView social_NaverBtn, social_KakaoBtn;
    Button social_BackBtn, social_NlogOutBtn, social_KlogOutBtn;

    SessionCallback sessionCallback = new SessionCallback();
    Session session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social_login);

        social_NaverBtn = findViewById(R.id.social_NaverBtn);
        social_KakaoBtn = findViewById(R.id.social_KakaoBtn);
        social_BackBtn = findViewById(R.id.social_BackBtn);
        social_NlogOutBtn = findViewById(R.id.social_NlogOutBtn);
        social_KlogOutBtn = findViewById(R.id.social_KlogOutBtn);

        // 세션 콜백 등록
        session = Session.getCurrentSession();
        session.addCallback(sessionCallback);


        //카카오로그인 이미지 클릭시
        social_KakaoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                session.open(AuthType.KAKAO_LOGIN_ALL, SocialLoginActivity.this);
                Log.d(TAG, "onClick: 카카오로그인완료");

                /*Intent intent = new Intent(getApplicationContext(), LoadingActivity.class);
                startActivity(intent);

                finish();*/
            }
        });

        //뒤로가기 버튼 클릭시
        social_BackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });


        //카카오 로그아웃 버튼 클릭시
        social_KlogOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserManagement.getInstance()
                        .requestLogout(new LogoutResponseCallback() {
                            @Override
                            public void onCompleteLogout() {
                                Log.d(TAG, "onCompleteLogout: 로그아웃완료");
                                Toast.makeText(SocialLoginActivity.this, "로그아웃 되었습니다.", Toast.LENGTH_SHORT).show();
                             }
                        });
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        // 세션 콜백 삭제
        Session.getCurrentSession().removeCallback(sessionCallback);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // 카카오톡|스토리 간편로그인 실행 결과를 받아서 SDK로 전달
        if (Session.getCurrentSession().handleActivityResult(requestCode, resultCode, data)) {
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
}
