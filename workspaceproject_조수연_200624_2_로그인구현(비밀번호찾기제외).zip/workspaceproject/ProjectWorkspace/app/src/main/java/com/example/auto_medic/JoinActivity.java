package com.example.auto_medic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class JoinActivity extends AppCompatActivity {

    String state;

    EditText join_etId, join_etPw, join_etPwChk, join_etNickName, join_etTel;
    Button join_btnJoin, join_IdChkBtn, join_btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        join_etId = findViewById(R.id.join_etId);
        join_etPw = findViewById(R.id.join_etPw);
        join_etPwChk = findViewById(R.id.join_etPwChk);
        join_etNickName = findViewById(R.id.join_etNickName);
        join_etTel = findViewById(R.id.join_etTel);
        join_btnJoin = findViewById(R.id.join_btnJoin);
        join_IdChkBtn = findViewById(R.id.join_IdChkBtn);
        join_btnCancel = findViewById(R.id.join_btnCancel);


    }
}
