package com.example.auto_medic;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.auto_medic.ATask.JoinChkEmail;
import com.example.auto_medic.ATask.JoinInsert;
import com.example.auto_medic.Dto.MemberDTO;

import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JoinActivity extends AppCompatActivity {

    String state;
    public static MemberDTO emailchkDTO = null;

    EditText join_etId, join_etPw, join_etPwChk, join_etNickName, join_etTel;
    Button join_btnJoin, join_IdChkBtn, join_btnCancel;
    TextView join_tvIdChk, join_tvPwChk2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        join_etId = findViewById(R.id.join_etId);
        join_etPw = findViewById(R.id.join_etPw);
        join_etPwChk = findViewById(R.id.join_etPwChk);
        join_etNickName = findViewById(R.id.join_etNickName);
        join_etTel = findViewById(R.id.join_etTel);
        join_btnJoin = findViewById(R.id.join_btnJoin);
        join_IdChkBtn = findViewById(R.id.join_IdChkBtn);
        join_btnCancel = findViewById(R.id.join_btnCancel);
        join_tvIdChk = findViewById(R.id.join_tvIdChk);
        join_tvPwChk2 = findViewById(R.id.join_tvPwChk2);

        //아이디 중복체크(가제) : 인증하기 버튼을 누르면 정규식 및 중복확인되도록함
        join_IdChkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //아이디(이메일) 형식 체크
                if(join_etId.getText().toString().length() == 0 ){  //아이디를 입력하지 않은 경우
                    Toast.makeText(JoinActivity.this, "아이디를 입력하세요!", Toast.LENGTH_SHORT).show();
                    join_etId.requestFocus();
                    return;
                } else if (!checkEmail(join_etId.getText().toString())) { //이메일 형식에 맞지 않는 경우
                    Toast.makeText(getApplicationContext(), "올바른 아이디 형식이 아닙니다!\n아이디는 이메일로 입력해주세요!", Toast.LENGTH_SHORT).show();
                    join_etId.setText("");
                    join_etId.requestFocus();
                    return;
                } else {
                    String id = join_etId.getText().toString();
                    JoinChkEmail joinChkEmail = new JoinChkEmail(id);

                    try {
                        joinChkEmail.execute().get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    if(emailchkDTO != null){
                        Toast.makeText(JoinActivity.this, "사용 불가능한 아이디 입니다!", Toast.LENGTH_SHORT).show();
                        emailchkDTO = null;
                    } else {
                        Toast.makeText(JoinActivity.this, "사용 가능한 아이디 입니다!", Toast.LENGTH_SHORT).show();
                        emailchkDTO = null;
                        //여기 부분에 스프링 연동하여 이메일 발송부분 작성 필요
                    }
                }
            }
        });

        //비밀번호 일치 불일치 체크
        join_etPwChk.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = join_etPw.getText().toString();
                String confirm = join_etPwChk.getText().toString();
                if(password.equals(confirm)){
                    join_tvPwChk2.setText("일치");
                    join_tvPwChk2.setTextColor(Color.GREEN);
                } else {
                    join_tvPwChk2.setText("불일치");
                    join_tvPwChk2.setTextColor(Color.RED);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {


            }

        });

        //회원가입 버튼 클릭시
        join_btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String member_email = join_etId.getText().toString();
                String member_password = join_etPw.getText().toString();
                String member_nickname = join_etNickName.getText().toString();
                String member_phonenum =  join_etTel.getText().toString();
                String member_chkpw = join_etPwChk.getText().toString();

                //아이디 체크 버튼 클릭시 메일링(추후 스프링 배워서 수정)
                join_IdChkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });

                //비밀번호 형식 체크
                if(join_etPw.getText().toString().length() == 0){   //비밀번호를 입력하지 않은경우
                    Toast.makeText(JoinActivity.this, "비밀번호를 입력하세요!", Toast.LENGTH_SHORT).show();
                    join_etPw.requestFocus();
                    return;
                } else if (join_etPw.getText().toString().length()<8 &&!isValidPassword(join_etPw.getText().toString())){   //비밀번호 형식에 맞지 않은 경우
                    Toast.makeText(getApplicationContext(), "올바른 비밀번호 형식이 아닙니다!\n비밀번호는 8자 이상, 알파벳 1개, 숫자 1개 및 특수 문자 1개를 포함해주세요!", Toast.LENGTH_SHORT).show();
                    join_etPw.setText("");
                    join_etPw.requestFocus();
                    return;
                }

                //비밀번호 확인 체크
                if(join_etPwChk.getText().toString().length() == 0){
                    Toast.makeText(JoinActivity.this, "비밀번호 확인란을 입력해주세요!", Toast.LENGTH_SHORT).show();
                    join_etPwChk.requestFocus();
                    return;
                }

                if(join_etNickName.getText().toString().length() == 0){
                    Toast.makeText(JoinActivity.this, "닉네임을 입력해주세요!", Toast.LENGTH_SHORT).show();
                    join_etNickName.requestFocus();
                }

                if(join_etTel.getText().toString().length() == 0){
                    Toast.makeText(JoinActivity.this, "전화번호를 입력해주세요!", Toast.LENGTH_SHORT).show();
                    join_etTel.requestFocus();
                }


                JoinInsert joinInsert = new JoinInsert(member_email, member_password, member_nickname, member_phonenum );
                try {
                    state = joinInsert.execute().get().trim();
                    Log.d("main:joinact0 : ", state);
                } catch (
                        ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(state.equals("1")){
                    Toast.makeText(JoinActivity.this, "가입성공 !!!\n로그인을 진행해주세요!", Toast.LENGTH_LONG).show();
                    Log.d("main:joinact", "가입성공 !!!");
                    finish();
                }
            }

        });

        join_btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    //이메일 형식 체크
    public static final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+"
    );

    private boolean checkEmail(String email) {
        return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
    }

    //비밀번호 형식 체크 (암호는 최소 8자 이상, 알파벳 1개, 숫자 1개 및 특수 문자 1개를 사용)
    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();

    }

}
