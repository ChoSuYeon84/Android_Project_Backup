package com.csslect.app.arducommand;

import org.springframework.ui.Model;

public interface ArduCommand {
	public void execute(Model model);
}
