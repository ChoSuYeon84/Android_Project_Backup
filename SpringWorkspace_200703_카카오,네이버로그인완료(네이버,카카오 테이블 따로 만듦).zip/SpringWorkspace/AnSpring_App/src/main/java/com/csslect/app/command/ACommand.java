package com.csslect.app.command;

import org.springframework.ui.Model;

public interface ACommand {
	public void execute(Model model);
}
