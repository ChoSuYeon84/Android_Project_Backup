package com.example.auto_medic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.auto_medic.ATask.JoinInsert;

import java.util.concurrent.ExecutionException;

public class JoinActivity extends AppCompatActivity {

    String state;

    EditText join_etId, join_etPw, join_etPwChk, join_etNickName, join_etTel;
    Button join_btnJoin, join_IdChkBtn, join_btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        join_etId = findViewById(R.id.join_etId);
        join_etPw = findViewById(R.id.join_etPw);
        join_etPwChk = findViewById(R.id.join_etPwChk);
        join_etNickName = findViewById(R.id.join_etNickName);
        join_etTel = findViewById(R.id.join_etTel);
        join_btnJoin = findViewById(R.id.join_btnJoin);
        join_IdChkBtn = findViewById(R.id.join_IdChkBtn);
        join_btnCancel = findViewById(R.id.join_btnCancel);

        //회원가입 버튼 클릭시
        join_btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String member_email = join_etId.getText().toString();
                String member_password = join_etPw.getText().toString();
                String member_nickname = join_etNickName.getText().toString();
                String member_phonenum =  join_etTel.getText().toString();

                JoinInsert joinInsert = new JoinInsert(member_email, member_password, member_nickname, member_phonenum );
                try {
                    state = joinInsert.execute().get().trim();
                    Log.d("main:joinact0 : ", state);
                } catch (
                        ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(state.equals("1")){
                    Toast.makeText(JoinActivity.this, "가입성공 !!!", Toast.LENGTH_SHORT).show();
                    Log.d("main:joinact", "가입성공 !!!");
                    finish();
                }else{
                    Toast.makeText(JoinActivity.this, "가입실패 !!!", Toast.LENGTH_SHORT).show();
                    Log.d("main:joinact", "가입실패 !!!");
                    finish();
                }
            }

        });

        join_btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
